# Uploading Sisonke to GitHub

1. Extract this ZIP.
2. Open your GitHub repository.
3. Select **Add file → Upload files**.
4. Upload the contents of this folder (not the parent folder itself).
5. Commit the files to the `main` branch.

Do not upload files ignored by `.gitignore` such as `build/`, `.dart_tool/`, IDE folders, signing keys, or `.env` files.
